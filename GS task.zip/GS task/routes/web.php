<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ExamtableController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::get('list',[ExamtableController::class,'list']);

Route::view('add','addqs');
Route::post('add',[ExamtableController::class,'addQue']);

Route::get('edit/{id}',[ExamtableController::class,'displayData']);
Route::post('edit',[ExamtableController::class,'update']);

Route::get('delete/{id}',[ExamtableController::class,'delete']);


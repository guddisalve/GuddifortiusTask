<h1>Multiple Choice Questions</h1>


<h3>Technical</h3>
<table border=1>
    <tr>
        <td>SR No.</td>
        <td>Question</td>
        <td>Choose currect option</td>
        <td>Edit/Delete</td>
    </tr>
    @php
    $b = 1;
    @endphp
    @foreach($questions as $question)
    @if($question->section == 1)
    <tr>
        <td>{{$b}}</td>
        <td> {{$question->description}}</td>
        <td><input type="radio" name="ans" value={{$question->a}} />{{$question->a}} <input type="radio" name="answer"
                value={{$question->b}} />{{$question->b}} <input type="radio" name="answer"
                value={{$question->c}} />{{$question->c}} <input type="radio" name="answer"
                value={{$question->d}} />{{$question->d}}</td>
        <td><a href={{"delete/".$question['id']}}>Delete</a>
            <a href={{"edit/".$question['id']}}>Edit</a>
        </td>
    </tr>
    @endif
    @php
    $b++;
    @endphp
    @endforeach
</table>
<h3>Aptitude</h3>
<table border=1>
    <tr>
        <td>SR No.</td>
        <td>Question</td>
        <td>Choose currect option</td>
        <td>Edit/Delete</td>
    </tr>
    @php
    $i = 1;
    @endphp
    @foreach($questions as $question)
    @if($question->section == 2)
    <tr>
        <td>{{$i}}</td>
        <td> {{$question->description}}</td>
        <td><input type="radio" name="ans" value={{$question->a}} />{{$question->a}} <input type="radio" name="answer"
                value={{$question->b}} />{{$question->b}} <input type="radio" name="answer"
                value={{$question->c}} />{{$question->c}} <input type="radio" name="answer"
                value={{$question->d}} />{{$question->d}}</td>
        <td><a href={{"delete/".$question['id']}}>Delete</a>
            <a href={{"edit/".$question['id']}}>Edit</a>
        </td>
    </tr>
    @endif
    @php
    $i++;
    @endphp
    @endforeach
</table>

<h3>Logical</h3>
<table border=1>
    <tr>
        <td>SR No.</td>
        <td>Question</td>
        <td>Choose currect option</td>
        <td>Edit/Delete</td>
    </tr>
    @php
    $c = 1;
    @endphp
    @foreach($questions as $question)
    @if($question->section == 3)
    <tr>
        <td>{{$c}}</td>
        <td> {{$question->description}}</td>
        <td><input type="radio" name="ans" value={{$question->a}} />{{$question->a}} <input type="radio" name="answer"
                value={{$question->b}} />{{$question->b}} <input type="radio" name="answer"
                value={{$question->c}} />{{$question->c}} <input type="radio" name="answer"
                value={{$question->d}} />{{$question->d}}</td>
        <td><a href={{"delete/".$question['id']}}>Delete</a>
            <a href={{"edit/".$question['id']}}>Edit</a>
        </td>
    </tr>
    @endif
    @php
    $c++;
    @endphp
    @endforeach
</table>
<div>
</div>
<style>
/* .w-5 {
    display: none;
} */
</style>
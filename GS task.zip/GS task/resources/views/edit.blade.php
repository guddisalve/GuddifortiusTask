<html>
<head>
<title>Edit Question</title>
</head>
<style>
 div {
  padding-top: 50px;
  padding-right: 50px;
  padding-bottom: 50px;
  padding-left: 200px;
}
</style>
<body>
    
<div>
<h1> Edit Question</h1>

<form action="/edit" method="POST">
@csrf
<input type="hidden" name="id" value={{$data['id']}}>
<input type="radio" name="section" value="1" <?php echo ($data->section=='1')?'checked':'' ?> />Technical
<br>
<input type="radio" name="section" value="2" <?php echo ($data->section=='2')?'checked':'' ?> />Aptitude
<br>
<input type="radio" name="section" value="3"<?php echo ($data->section=='3')?'checked':'' ?> />Logical
<br>
<h3>Enter question here</h3>
<textarea name="question" rows="5" cols="50" wrap="soft"> {{$data['description']}}</textarea>
<h3>Enter the options</h3>
<strong>1.</strong><input type="text" name="a" value="{{$data['a']}}">><br><br>
<strong>2.</strong><input type="text" name="b" value="{{$data['b']}}"><br><br>
<strong>3.</strong><input type="text" name="c" value="{{$data['c']}}"><br><br>
<strong>4.</strong><input type="text" name="d" value="{{$data['d']}}"><br><br>
<h3>Enter the Correct Answer</h3><br>
<strong>Answer</strong><input type="text" name="answer" value="{{$data['answer']}}"><br><br>

<button type="submit" style="background-color : lightskyblue;">Edit</button>
</form>

<div>
</body>
</html>
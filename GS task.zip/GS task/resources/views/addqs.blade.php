<html>

<head>
    <title>Add New Question</title>
</head>
<style>
div {
  padding-top: 50px;
  padding-right: 50px;
  padding-bottom: 50px;
  padding-left: 200px;
}
</style>

<body>

    
    <div>
    <h1> Add New Question</h1>
        <form action="" method="POST">
            @csrf
            <input type="radio" name="section" value="1" />Technical
            <br>
            <input type="radio" name="section" value="2" />Aptitude
            <br>
            <input type="radio" name="section" value="3" />Logical
            <br>
            <h3>Enter question here</h3>
            <textarea name="question" rows="5" cols="50" wrap="soft"></textarea>
            
            <h3>Enter the options </h3>
            <strong>1.</strong><input type="text" name="a" placeholder="Enter option"><br><br>
            <strong>2.</strong><input type="text" name="b" placeholder="Enter option"><br><br>
            <strong>3.</strong><input type="text" name="c" placeholder="Enter option"><br><br>
            <strong>4.</strong><input type="text" name="d" placeholder="Enter option"><br><br>
            <h3>Enter the Correct Answer</h3><br>
            <strong>Ans.</strong><input type="text" name="answer" placeholder="Enter Answer"><br><br>

            <button type="submit" style="background-color :lightskyblue;">Add</button>
        </form>
    </div>
</body>

</html>
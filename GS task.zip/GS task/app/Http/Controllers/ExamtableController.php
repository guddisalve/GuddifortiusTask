<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\examtable;

class ExamtableController extends Controller
{
    function list()
    {
        $data = examtable::all();
        // print("<pre>");
        // print_r($data);
        // exit;
        return view('list', ['questions' => $data]);
    }


    function addQue(Request $req)
    {
        // echo "hello";
        // print_r($req->all());
        // exit;
        $req->validate([
            "question" => "required",
            "a" => "required",
            "b" => "required",
            "c" => "required",
            "d" => "required",
            "answer" => "required",
            "section" => "required",
        ]);
        $ques = new examtable;
        $ques->description = $req->question;
        $ques->a = $req->a;
        $ques->b = $req->b;
        $ques->c = $req->c;
        $ques->d = $req->d;
        $ques->answer = $req->answer;
        $ques->section = $req->section;
        $ques->save();
        return redirect('add');
    }


    function displayData($id)
    {
        $data = examtable::find($id);
        // print_r($data);
        // exit;
        return view('edit', ['data' => $data]);
    }

    function update(Request $req)
    {
        $req->validate([
            "question" => "required",
            "a" => "required",
            "b" => "required",
            "c" => "required",
            "d" => "required",
            "answer" => "required",
            "section" => "required",
        ]);
        $data = examtable::find($req->id);
        $data->description = $req->question;
        $data->a = $req->a;
        $data->b = $req->b;
        $data->c = $req->c;
        $data->d = $req->d;
        $data->answer = $req->answer;
        $data->section = $req->section;
        $data->save();
        return redirect('list');
    }

    function delete($id)
    {
        $data = examtable::find($id);
        $data->delete();
        return redirect('list');
    }
}
